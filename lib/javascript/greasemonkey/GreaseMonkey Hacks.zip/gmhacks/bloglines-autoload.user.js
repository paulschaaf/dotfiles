// ==UserScript==
// @name          Bloglines Autoloader
// @namespace     http://www.oreilly.com/catalog/greasemonkeyhks/
// @description   Auto-display unread items in Bloglines
// @include       http://bloglines.com/myblogs*
// @include       http://www.bloglines.com/myblogs*
// ==/UserScript==

if (typeof doLoadAll != 'undefined') {
    doLoadAll();
}
