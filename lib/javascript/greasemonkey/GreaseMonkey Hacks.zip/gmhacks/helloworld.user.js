// ==UserScript==
// @name          Hello World
// @namespace     http://www.oreilly.com/catalog/greasemonkeyhcks/
// @description   example script to alert "Hello world!" on every page
// @include       *
// @exclude       http://oreilly.com/*
// @exclude       http://www.oreilly.com/*
// ==/UserScript==

alert('Hello world!');
