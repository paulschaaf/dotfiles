#!/bin/bash

set -x

if [ "$1" != "startup" ]; then
    if [ "$1" = "restart" -o "$1" = "stop" -o "$1" = "kill" ]; then
        echo Killing existing agent
        pskill ssh-agent.exe
        [ "$1" = "stop" -o "$1" = "kill" ] && exit
        shift
    fi

    /bin/pgrep ssh-agent > /dev/null
    if [ "$?" -eq "0" ]; then
        echo Use \"start-ssh-agent.sh restart\" if you want to kill the existing daemon.
        exit
    fi
fi

PATH=`/usr/bin/cygpath -aup $CYGPATH`:$PATH
export PATH

rm -rf /tmp/ssh-*
eval `ssh-agent &`

echo $SSH_AGENT_PID; echo $SSH_AUTH_SOCK

for var in SSH_AGENT_PID SSH_AUTH_SOCK; do
    export ${var}
    eval value=\$${var}

    # set values in global environment for Windows user
    setx ${var} ${value}
    echo export ${var}=${value}  # setx ${var} ${value}
done

# echo $SSH_ASKPASS=

if [ -e $HOME/.ssh/ssh-open ]; then
    echo adding ssh-open
    cat $HOME/.ssh/ssh-open | xargs ssh-add
fi
