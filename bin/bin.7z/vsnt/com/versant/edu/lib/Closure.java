package com.versant.edu.lib;

public class Closure {
	public void exec(Object item) throws Exception {
	}
	public void exec(Object item, Object item2) throws Exception {
	}
	public void exec(Object item, Object item2, Object item3) throws Exception {
	}
	public void exec(Object[] items) throws Exception {
	}
}
